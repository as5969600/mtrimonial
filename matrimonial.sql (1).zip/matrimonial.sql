-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2021 at 09:19 AM
-- Server version: 5.1.54
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `matrimonial`
--

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE IF NOT EXISTS `inbox` (
  `mess_code` varchar(255) NOT NULL,
  `tos` varchar(255) NOT NULL,
  `froms` varchar(255) NOT NULL,
  `tcode` varchar(255) NOT NULL,
  `fcode` varchar(255) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`mess_code`, `tos`, `froms`, `tcode`, `fcode`, `msg`, `date`) VALUES
('NYyws4', 'himanshu@gmail.com', 'as596960@gmail.com', 'KPs0qG', 'TsKgIW', 'aur mote', 'Mon Jul 22 14:05:21 PDT 2019'),
('zUwlLG', 'lovi@gmail.com', 'as596960@gmail.com', 'lNai5y', 'TsKgIW', 'namastey dii', 'Mon Jul 22 14:07:59 PDT 2019'),
('aeKZLk', 'himanshu@gmail.com', 'as596960@gmail.com', 'KPs0qG', 'TsKgIW', 'hgsashdhjkd', 'Sat Jul 20 20:02:31 PDT 2019'),
('ODTnai', 'as596960@gmail.com', 'chirag@gmail.com', 'TsKgIW', 'ly4GC1', 'i', 'Sun Jul 21 18:22:39 PDT 2019'),
('dsASW9', 'as596960@gmail.com', 'chirag@gmail.com', 'TsKgIW', 'ly4GC1', 'hello bhaiya', 'Sun Jul 21 18:22:50 PDT 2019'),
('7WcLJi', 'as596960@gmail.com', 'lovi@gmail.com', 'TsKgIW', 'lNai5y', 'aur kesa hai', 'Mon Jul 22 13:33:59 PDT 2019'),
('IU6iMs', 'as596960@gmail.com', 'lovi@gmail.com', 'TsKgIW', 'lNai5y', 'kha hai', 'Mon Jul 22 13:34:39 PDT 2019');

-- --------------------------------------------------------

--
-- Table structure for table `interest`
--

CREATE TABLE IF NOT EXISTS `interest` (
  `intcode` varchar(255) NOT NULL,
  `tos` varchar(255) NOT NULL,
  `froms` varchar(255) NOT NULL,
  `tcode` varchar(255) NOT NULL,
  `fcode` varchar(255) NOT NULL,
  `noofrequest` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date_int` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interest`
--

INSERT INTO `interest` (`intcode`, `tos`, `froms`, `tcode`, `fcode`, `noofrequest`, `status`, `date_int`) VALUES
('g4xN3L', 'himanshu@gmail.com', 'as596960@gmail.com', 'KPs0qG', 'TsKgIW', 0, 1, 'Sat Jul 27 12:32:50 PDT 2019'),
('JUV9SY', 'lovi@gmail.com', 'as596960@gmail.com', 'lNai5y', 'TsKgIW', 3, -1, 'Sat Jul 27 04:31:24 PDT 2019'),
('x0ROkM', 'kiran@gmail.com', 'as596960@gmail.com', 'bdT2Jo', 'TsKgIW', 0, 0, 'Sat Jul 27 05:03:53 PDT 2019'),
('usxQw6', 'as596960@gmail.com', 'kiran@gmail.com', 'TsKgIW', 'bdT2Jo', 0, 0, 'Sat Dec 21 00:58:11 PKT 2019');

-- --------------------------------------------------------

--
-- Table structure for table `registor`
--

CREATE TABLE IF NOT EXISTS `registor` (
  `profile_for` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mother_occupation` varchar(255) NOT NULL,
  `father_occupation` varchar(255) NOT NULL,
  `sisters` int(11) NOT NULL,
  `brothers` int(11) NOT NULL,
  `stay` varchar(255) NOT NULL,
  `highest_education` varchar(255) NOT NULL,
  `UG_degree` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `annual_income` varchar(255) NOT NULL,
  `age_p` varchar(255) NOT NULL,
  `height_p` varchar(255) NOT NULL,
  `marital_status_p` varchar(255) NOT NULL,
  `religion_p` varchar(255) NOT NULL,
  `caste_p` varchar(255) NOT NULL,
  `education_p` varchar(255) NOT NULL,
  `occupation_p` varchar(255) NOT NULL,
  `income_p` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registor`
--

INSERT INTO `registor` (`profile_for`, `sname`, `age`, `height`, `gender`, `dob`, `religion`, `mobile`, `email`, `password`, `mother_occupation`, `father_occupation`, `sisters`, `brothers`, `stay`, `highest_education`, `UG_degree`, `occupation`, `annual_income`, `age_p`, `height_p`, `marital_status_p`, `religion_p`, `caste_p`, `education_p`, `occupation_p`, `income_p`, `code`) VALUES
('myself', 'akash', '20', '5.7', 'Male', '08/31/1998', 'Hindu', '9828132130', 'as596960@gmail.com', '12345', 'teacher', 'teacher', 1, 1, 'india', 'mba', 'B.tech', 'software student', '15 lakh', '21', '5.5', 'Married', 'Christian', 'pandit', 'not important', 'student', '10 lakh', 'TsKgIW'),
('Friend', 'amit jain', '20', '5.7 inch', 'Male', '07/02/2019', 'Jain', '487587458', 'amitjain@gmail.com', 'amit', 'housewife', 'Bussiness man', 1, 0, 'india', 'p.hd', 'B.tech', 'student', '20 lakh', 'above 20', 'above 5.5', 'Single', 'Jain', 'jain', 'not important', 'nothing matter', 'not matter', 'tT40ji'),
('Brother', 'Chirag sharma', '20', '5.7 inch', 'Male', '02/10/2000', 'Hindu', '9672110578', 'chirag@gmail.com', 'chirag', 'teacher', 'teacher', 1, 1, 'india', 'llb+ba', 'llb', 'null', '10 lakh', '18', '5.6', 'Single', 'Hindu', 'pandit', 'not important', 'nothing matter', 'not matter', 'ly4GC1'),
('Myself', 'himanshu', '22', '5.7', 'Male', '09/16/1998', 'Hindu', '3455667778', 'himanshu@gmail.com', 'himanshu', 'housewife', 'Bussiness man', 0, 0, 'india', 'phd', 'B.tech', 'student', '20 lakh', 'above 20', 'above 5.5', 'Single', 'Christian', 'brahamin', 'post graduate', 'nothing matter', '10 lakh', 'KPs0qG'),
('Sister', 'kiran singh', '24', '5.5', 'Female', '02/10/1995', 'Hindu', '32546554475', 'kiran@gmail.com', 'kiran', 'housewife', 'police man', 0, 2, 'india', 'MD', 'MBBS', 'doctor', '50 lakh', 'above 24', '5.9', 'Single', 'No Religious Belief', 'not matter', 'MBBS', 'doctor', '1 crore', 'bdT2Jo'),
('Sister', 'lovi shrma', '25', '5.2', 'Female', '06/23/1995', 'Hindu', '132343434', 'lovi@gmail.com', 'lovi', 'teacher', 'teacher', 1, 1, 'india', 'MD', 'MBBS', 'doctor', '10 lakh', '24', '5.5', 'Single', 'No Religious Belief', 'not matter', 'MBBS', 'doctor', '50 lakh', 'lNai5y'),
('Friend', 'ajay nagar', '22', '5.9', 'Male', '08/03/1998', 'Hindu', '8392838247', 'ajay@gmail.com', 'ajay', 'housewife', 'farmer', 2, 0, 'africa', 'b.tech', 'b.tech', 'student', '20 lakh', '21', '5.7', 'Single', 'Hindu', 'not matter', 'under graduate', 'housewife', '0', 'v1n3Rm'),
('Brother', 'danish anees solanki', '22', '6', 'Male', '09/02/1998', 'Muslim', '8476467477', 'danish@gmail.com', 'danish123', 'housewife', 'private employe', 0, 1, 'india', 'b.tech', 'b.tech', 'student', '0', '20', '5', 'Single', 'Muslim', 'solanki', 'B.A pass', 'housewife', '6.5 lakh', 'e1EwVZ'),
('Brother', 'ankit prajapati', '22', '5.9', 'Male', '27/11/1997', 'Hindu', '8875527430', 'ankitprajapati431@gmail.com', '1234567', 'housewife', 'govt employee', 2, 0, 'india', 'b.tech', 'b.tech', 'social worker', '0', '21', '5.5', 'Single', 'No Religious Belief', 'prajapati', 'B.A pass', 'housewife', '0', 'gkGpsc'),
('Brother', 'kamal sharma', '', '', 'Male', '04/27/2020', 'Hindu', '9828132130', 'kamal123@gmail.com', 'kamal123', '', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', 'IYkbpd');
